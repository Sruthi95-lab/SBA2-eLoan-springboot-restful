package com.iiht.training.eloan.exception;

public class LoanNotFoundException extends RuntimeException{

	public LoanNotFoundException(String message) {
		super(message);
	}
}
