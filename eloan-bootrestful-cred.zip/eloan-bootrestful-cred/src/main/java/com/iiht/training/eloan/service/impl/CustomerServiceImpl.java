package com.iiht.training.eloan.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.LoanDto;
import com.iiht.training.eloan.dto.LoanOutputDto;
import com.iiht.training.eloan.dto.ProcessingDto;
import com.iiht.training.eloan.dto.SanctionDto;
import com.iiht.training.eloan.dto.SanctionOutputDto;
import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Loan;
import com.iiht.training.eloan.entity.ProcessingInfo;
import com.iiht.training.eloan.entity.SanctionInfo;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.exception.CustomerNotFoundException;
import com.iiht.training.eloan.exception.LoanNotFoundException;
import com.iiht.training.eloan.repository.LoanRepository;
import com.iiht.training.eloan.repository.ProcessingInfoRepository;
import com.iiht.training.eloan.repository.SanctionInfoRepository;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private LoanRepository loanRepository;
	
	@Autowired
	private ProcessingInfoRepository pProcessingInfoRepository;
	
	
	@Autowired
	private SanctionInfoRepository sanctionInfoRepository;
	
	
	
	private UserDto convertCustomerEntityToOutputDto(Users users) 
	{
		UserDto userOutputDTO = new UserDto();
		userOutputDTO.setId(users.getId());
		userOutputDTO.setFirstName(users.getFirstName());
		userOutputDTO.setLastName(users.getLastName());
		userOutputDTO.setEmail(users.getEmail());
		userOutputDTO.setMobile(users.getMobile());
		
		return userOutputDTO;
	}
	
	
	
	private Users convertCustomerInputDtoToEntity(UserDto userInputDTO) 
	{
		Users users = new Users();
		users.setId(userInputDTO.getId());
		users.setFirstName(userInputDTO.getFirstName());
		users.setLastName(userInputDTO.getLastName());
		users.setEmail(userInputDTO.getEmail());
		users.setMobile(userInputDTO.getMobile());
		users.setRole("Customer");
		return users;
	}
	
	
	
	
	private LoanDto convertLoandetailsEntityToOutputDto(Loan loandetails) 
	{
		LoanDto loandetailsOutputDTO = new LoanDto();
		loandetailsOutputDTO.setLoanName(loandetails.getLoanName());
		loandetailsOutputDTO.setLoanAmount(loandetails.getLoanAmount());
		loandetailsOutputDTO.setLoanApplicationDate(loandetails.getLoanApplicationDate());
		loandetailsOutputDTO.setBusinessStructure(loandetails.getBusinessStructure());
		loandetailsOutputDTO.setBillingIndicator(loandetails.getBillingIndicator());
		loandetailsOutputDTO.setTaxIndicator(loandetails.getTaxIndicator());
		return loandetailsOutputDTO;
	}
	
	
	
	private LoanOutputDto convertloanEntityToOutputDto(Loan loan) 
	{
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		
		loanOutputDto.setLoanAppId(loan.getId());
		
		
		int statusval = loan.getStatus();
		switch(statusval) 
			{
			case 0:
				loanOutputDto.setStatus("APPLIED");
				break;
			case 1:
				loanOutputDto.setStatus("PROCESSED");
				break;
			case 2:
				loanOutputDto.setStatus("SANCTIONED");
				break;
			case -1:
				loanOutputDto.setStatus("REJECTED");
				break;
			}
		
		if(statusval==-1 ||statusval==2) {
			loanOutputDto.setRemark(loan.getRemark());
		}
		
		return loanOutputDto;
	}
	
	
	private ProcessingDto convertProcessEntityToOutputDto(ProcessingInfo processInfo) 
	{
		ProcessingDto processOutputDto = new ProcessingDto();
		processOutputDto.setAcresOfLand(processInfo.getAcresOfLand());
		processOutputDto.setLandValue(processInfo.getLandValue());
		processOutputDto.setAppraisedBy(processInfo.getAppraisedBy());
		processOutputDto.setValuationDate(processInfo.getValuationDate());
		processOutputDto.setAddressOfProperty(processInfo.getAddressOfProperty());
		processOutputDto.setSuggestedAmountOfLoan(processInfo.getSuggestedAmountOfLoan());
		
		return processOutputDto;
	}
	
	
	
	private ProcessingInfo convertProcessInputDtoToEntity(ProcessingDto processOutputDto) 
	{
		ProcessingInfo processInfo = new ProcessingInfo();
		processInfo.setAcresOfLand(processOutputDto.getAcresOfLand());
		processInfo.setLandValue(processOutputDto.getLandValue());
		processInfo.setAppraisedBy(processOutputDto.getAppraisedBy());
		processInfo.setValuationDate(processOutputDto.getValuationDate());
		processInfo.setAddressOfProperty(processOutputDto.getAddressOfProperty());
		processInfo.setSuggestedAmountOfLoan(processOutputDto.getSuggestedAmountOfLoan());
		return processInfo;
	}
	
private SanctionOutputDto convertSanctionEntityToOutputDto(SanctionInfo newSancInfo) {
		
		SanctionOutputDto sanctionOutputDto = new SanctionOutputDto();
		sanctionOutputDto.setLoanAmountSanctioned(newSancInfo.getLoanAmountSanctioned());
		sanctionOutputDto.setLoanClosureDate(newSancInfo.getLoanClosureDate());
		sanctionOutputDto.setMonthlyPayment(newSancInfo.getMonthlyPayment());
		sanctionOutputDto.setPaymentStartDate(newSancInfo.getPaymentStartDate());
		sanctionOutputDto.setTermOfLoan(newSancInfo.getTermOfLoan());
		
		return sanctionOutputDto;
	}
	
	
	private LoanOutputDto convertlistloanEntityToOutputDto(Loan loan) 
	{
		
		
		
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		
		loanOutputDto.setCustomerId(loan.getCustomerId());
		Long customerId =loan.getCustomerId();
		Long Id =loan.getId();
		Long loanAppId =loan.getId();
		
		Users userdetails = this.usersRepository.findById(customerId).orElse(null);
		UserDto userdto = this.convertCustomerEntityToOutputDto(userdetails);
		
		Loan Loandetails = this.loanRepository.findById(Id).orElse(null);
		LoanDto loandto = this.convertLoandetailsEntityToOutputDto(Loandetails);
		
		
		
		int statusval = loan.getStatus();
		switch(statusval) 
			{
			case 0:
				loanOutputDto.setStatus("APPLIED");
				break;
			case 1:
				loanOutputDto.setStatus("PROCESSED");
				break;
			case 2:
				loanOutputDto.setStatus("SANCTIONED");
				break;
			case -1:
				loanOutputDto.setStatus("REJECTED");
				break;
			}
		
		if(statusval==-1) {
			loanOutputDto.setRemark(loan.getRemark());
		}
		
		if(statusval==1) {
			ProcessingInfo processinfo = this.pProcessingInfoRepository.findById(loanAppId).orElse(null);
			ProcessingDto processOutputDto = this.convertProcessEntityToOutputDto(processinfo);
			loanOutputDto.setProcessingDto(processOutputDto);
		}
		if(statusval==2){
			ProcessingInfo processinfo = this.pProcessingInfoRepository.findById(loanAppId).orElse(null);
			ProcessingDto processOutputDto = this.convertProcessEntityToOutputDto(processinfo);
			loanOutputDto.setProcessingDto(processOutputDto);
			
			SanctionInfo sanctionInfo = this.sanctionInfoRepository.findById(loanAppId).orElse(null);
			SanctionOutputDto sanctionDto = this.convertSanctionEntityToOutputDto(sanctionInfo);
			loanOutputDto.setSanctionOutputDto(sanctionDto);
		}
		loanOutputDto.setLoanAppId(Id);
		loanOutputDto.setLoanDto(loandto);
		loanOutputDto.setUserDto(userdto);
		
		return loanOutputDto;
	}
	
	
	private Loan convertloanInputDtoToEntity(LoanDto loanInputDTO) 
	{
		Loan loan = new Loan();
		loan.setLoanName(loanInputDTO.getLoanName());
		loan.setLoanAmount(loanInputDTO.getLoanAmount());
		loan.setLoanApplicationDate(loanInputDTO.getLoanApplicationDate());
		loan.setBusinessStructure(loanInputDTO.getBusinessStructure());
		loan.setBillingIndicator(loanInputDTO.getBillingIndicator());
		loan.setTaxIndicator(loanInputDTO.getTaxIndicator());
		loan.setStatus(0);
		return loan;
	}
	
	
	
	
	@Override
	public UserDto register(UserDto userDto) {
		// TODO Auto-generated method stub
		
		Users users = this.convertCustomerInputDtoToEntity(userDto);
		// save into DB, returns newly added record
		Users newUser = this.usersRepository.save(users);
		// convert entity into dto
		UserDto userOutputDto =  this.convertCustomerEntityToOutputDto(newUser);
		return userOutputDto;
	}

	
	
	@Override
	public LoanOutputDto applyLoan(Long customerId, LoanDto loanDto) {
		// TODO Auto-generated method stub
		
		// User DTO part
		Users userdetails = this.usersRepository.findById(customerId).orElse(null);
		if(userdetails ==null)
			throw new CustomerNotFoundException("No Customer found with the id in our system!!");
		UserDto userdto = this.convertCustomerEntityToOutputDto(userdetails);
		// Loan part
		Loan loan = this.convertloanInputDtoToEntity(loanDto);
		loan.setCustomerId(customerId);
		Loan newLoan = this.loanRepository.save(loan);
		Long loanID = newLoan.getId();
		
		Loan loandetails = this.loanRepository.findById(loanID).orElse(null);
		LoanDto loandto = this.convertLoandetailsEntityToOutputDto(loandetails);
		
		
		
		LoanOutputDto loanOutputDto =  this.convertloanEntityToOutputDto(newLoan);
		//System.out.println(customerId);
		loanOutputDto.setCustomerId(customerId);
		loanOutputDto.setUserDto(userdto);
		loanOutputDto.setLoanDto(loandto);
		
		return loanOutputDto;
	}

	@Override
	public LoanOutputDto getStatus(Long loanAppId) {
		// TODO Auto-generated method stub
		
		Loan loandetails = this.loanRepository.findById(loanAppId).orElse(null);
		if(loandetails ==null)
			throw new LoanNotFoundException("No Loan found with the id in our system!!");
		Long customerid = loandetails.getCustomerId();
		int status = loandetails.getStatus();
		LoanDto loanDto= this.convertLoandetailsEntityToOutputDto(loandetails);
		Users userdetails = this.usersRepository.findById(customerid).orElse(null);
		UserDto userdto = this.convertCustomerEntityToOutputDto(userdetails);
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		loanOutputDto.setCustomerId(customerid);
		loanOutputDto.setLoanAppId(loanAppId);
		loanOutputDto.setUserDto(userdto);
		loanOutputDto.setLoanDto(loanDto);
	
		switch(status) 
		{
			case 0:
				loanOutputDto.setStatus("APPLIED");
				break;
			case 1:
				loanOutputDto.setStatus("PROCESSED");
				break;
			case 2:
				loanOutputDto.setStatus("SANCTIONED");
				break;
			case -1:
				loanOutputDto.setStatus("REJECTED");
				break;
		}
		
		if(status==-1) {
			loanOutputDto.setRemark(loandetails.getRemark());
		}
		if(status==1) {
			ProcessingInfo processinfo = this.pProcessingInfoRepository.findById(loanAppId).orElse(null);
			ProcessingDto processOutputDto = this.convertProcessEntityToOutputDto(processinfo);
			loanOutputDto.setProcessingDto(processOutputDto);
		}
		if(status==2){
			
			ProcessingInfo processinfo = this.pProcessingInfoRepository.findById(loanAppId).orElse(null);
			ProcessingDto processOutputDto = this.convertProcessEntityToOutputDto(processinfo);
			loanOutputDto.setProcessingDto(processOutputDto);
			
			SanctionInfo sanctionInfo = this.sanctionInfoRepository.findById(loanAppId).orElse(null);
			SanctionOutputDto sanctionDto = this.convertSanctionEntityToOutputDto(sanctionInfo);
			loanOutputDto.setSanctionOutputDto(sanctionDto);
		}
			
		return loanOutputDto;
	}

	@Override
	public List<LoanOutputDto> getStatusAll(Long customerId) {
		// TODO Auto-generated method stub
		
		
		List<Loan> loans = this.loanRepository.findBycustomerId(customerId);
		if(loans.toString().equals("[]") ) {
			throw new CustomerNotFoundException("No Customer found with the id in our system!!");
		}
		List<LoanOutputDto> loanDtos = 
				loans.stream()
						 .map(this :: convertlistloanEntityToOutputDto)
						 .collect(Collectors.toList());
		
		return loanDtos; 
			
	}
	
}
