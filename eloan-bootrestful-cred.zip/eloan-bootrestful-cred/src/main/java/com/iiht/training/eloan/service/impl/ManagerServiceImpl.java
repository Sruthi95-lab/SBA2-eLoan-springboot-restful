package com.iiht.training.eloan.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.LoanDto;
import com.iiht.training.eloan.dto.LoanOutputDto;
import com.iiht.training.eloan.dto.ProcessingDto;
import com.iiht.training.eloan.dto.RejectDto;
import com.iiht.training.eloan.dto.SanctionDto;
import com.iiht.training.eloan.dto.SanctionOutputDto;
import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Loan;
import com.iiht.training.eloan.entity.ProcessingInfo;
import com.iiht.training.eloan.entity.SanctionInfo;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.exception.AlreadyFinalizedException;
import com.iiht.training.eloan.exception.LoanNotFoundException;
import com.iiht.training.eloan.exception.ManagerNotFoundException;
import com.iiht.training.eloan.repository.LoanRepository;
import com.iiht.training.eloan.repository.ProcessingInfoRepository;
import com.iiht.training.eloan.repository.SanctionInfoRepository;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.ManagerService;

@Service
public class ManagerServiceImpl implements ManagerService {

	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private LoanRepository loanRepository;
	
	@Autowired
	private ProcessingInfoRepository pProcessingInfoRepository;
	
	@Autowired
	private SanctionInfoRepository sanctionInfoRepository;
	
	
	
	private UserDto convertCustomerEntityToOutputDto(Users users) 
	{
		UserDto userOutputDTO = new UserDto();
		userOutputDTO.setId(users.getId());
		userOutputDTO.setFirstName(users.getFirstName());
		userOutputDTO.setLastName(users.getLastName());
		userOutputDTO.setEmail(users.getEmail());
		userOutputDTO.setMobile(users.getMobile());
		
		return userOutputDTO;
	}
	
	
	
	private SanctionInfo convertSanctionInputDtoToEntity(Long managerId, Long loanAppId,SanctionDto sanctionInputDTO) 
	{
		SanctionInfo sanctioninfo = new SanctionInfo();
		sanctioninfo.setLoanAppId(loanAppId);
		sanctioninfo.setManagerId(managerId);
		sanctioninfo.setTermOfLoan(sanctionInputDTO.getTermOfLoan());
		sanctioninfo.setLoanAmountSanctioned(sanctionInputDTO.getLoanAmountSanctioned());
		sanctioninfo.setPaymentStartDate(sanctionInputDTO.getPaymentStartDate());
		
		String paymentstartdate = sanctionInputDTO.getPaymentStartDate();
		double termofloan = sanctionInputDTO.getTermOfLoan();
		double sanLoanAmount =sanctionInputDTO.getLoanAmountSanctioned();
		double interestrate = 6.5;
		double calc = Math.pow((1+interestrate/100),(termofloan));
		double termPaymentAmt = (sanLoanAmount) *calc ;
		//double termPaymentAmt = sanLoanAmount*calc;
		int endyear = (int) Math.ceil(termofloan);
		Date date;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse(paymentstartdate);
		
		//LocalDate loanClosureDate = LocalDate.of(year, month, dayOfMonth).plusMonths(monthsToAdd);
		//Date d=new Date();
		//int year=d.getYear();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.YEAR, endyear);
		String loanClosureDate = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
		double monthlyPayment = termPaymentAmt/termofloan;
		
		sanctioninfo.setLoanClosureDate(loanClosureDate);
		sanctioninfo.setMonthlyPayment(monthlyPayment);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return sanctioninfo;
	}
	
	private SanctionOutputDto convertSanctionEntityToOutputDto(SanctionInfo newSancInfo) {
		
		SanctionOutputDto sanctionOutputDto = new SanctionOutputDto();
		sanctionOutputDto.setLoanAmountSanctioned(newSancInfo.getLoanAmountSanctioned());
		sanctionOutputDto.setLoanClosureDate(newSancInfo.getLoanClosureDate());
		sanctionOutputDto.setMonthlyPayment(newSancInfo.getMonthlyPayment());
		sanctionOutputDto.setPaymentStartDate(newSancInfo.getPaymentStartDate());
		sanctionOutputDto.setTermOfLoan(newSancInfo.getTermOfLoan());
		
		return sanctionOutputDto;
	}
	
	private ProcessingDto convertProcessEntityToOutputDto(ProcessingInfo processInfo) 
	{
		ProcessingDto processOutputDto = new ProcessingDto();
		processOutputDto.setAcresOfLand(processInfo.getAcresOfLand());
		processOutputDto.setLandValue(processInfo.getLandValue());
		processOutputDto.setAppraisedBy(processInfo.getAppraisedBy());
		processOutputDto.setValuationDate(processInfo.getValuationDate());
		processOutputDto.setAddressOfProperty(processInfo.getAddressOfProperty());
		processOutputDto.setSuggestedAmountOfLoan(processInfo.getSuggestedAmountOfLoan());
		
		return processOutputDto;
	}
	
	
	
	
	
	
	private LoanDto convertLoandetailsEntityToOutputDto(Loan loandetails) 
	{
		LoanDto loandetailsOutputDTO = new LoanDto();
		loandetailsOutputDTO.setLoanName(loandetails.getLoanName());
		loandetailsOutputDTO.setLoanAmount(loandetails.getLoanAmount());
		loandetailsOutputDTO.setLoanApplicationDate(loandetails.getLoanApplicationDate());
		loandetailsOutputDTO.setBusinessStructure(loandetails.getBusinessStructure());
		loandetailsOutputDTO.setBillingIndicator(loandetails.getBillingIndicator());
		loandetailsOutputDTO.setTaxIndicator(loandetails.getTaxIndicator());
		return loandetailsOutputDTO;
	}
	
	
	
	private LoanOutputDto convertlistloanEntityToOutputDto(Loan loan) 
	{
		
		
		
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		
		loanOutputDto.setCustomerId(loan.getCustomerId());
		Long customerId =loan.getCustomerId();
		Long Id =loan.getId();
		Long loanAppId =loan.getId();
		
		Users userdetails = this.usersRepository.findById(customerId).orElse(null);
		UserDto userdto = this.convertCustomerEntityToOutputDto(userdetails);
		
		Loan Loandetails = this.loanRepository.findById(Id).orElse(null);
		LoanDto loandto = this.convertLoandetailsEntityToOutputDto(Loandetails);
		
		ProcessingInfo processinfo = this.pProcessingInfoRepository.findById(loanAppId).orElse(null);
		ProcessingDto processingDto = this.convertProcessEntityToOutputDto(processinfo);
		
		int statusval = loan.getStatus();
		switch(statusval) 
			{
			case 0:
				loanOutputDto.setStatus("APPLIED");
				break;
			case 1:
				loanOutputDto.setStatus("PROCESSED");
				break;
			case 2:
				loanOutputDto.setStatus("SANCTIONED");
				break;
			case -1:
				loanOutputDto.setStatus("REJECTED");
				break;
			}
		
		if(statusval==-1) {
			loanOutputDto.setRemark(loan.getRemark());
		}
		
		loanOutputDto.setLoanAppId(Id);
		loanOutputDto.setLoanDto(loandto);
		loanOutputDto.setUserDto(userdto);
		loanOutputDto.setProcessingDto(processingDto);
		return loanOutputDto;
	}
	
	
	@Override
	public List<LoanOutputDto> allProcessedLoans() {
		// TODO Auto-generated method stub
		 List<Loan> Loans = this.loanRepository.findByStatus(1);
		 List<LoanOutputDto> loanDtos = Loans.stream()
							 .map(this ::convertlistloanEntityToOutputDto )
							 .collect(Collectors.toList());
			
			return loanDtos;
	}

	@Override
	public RejectDto rejectLoan(Long managerId, Long loanAppId, RejectDto rejectDto) {
		// TODO Auto-generated method stub
		//RejectDto rejectDto = 
		
		Loan Loandetails = this.loanRepository.findById(loanAppId).orElse(null);
		if (Loandetails == null) {
			throw new LoanNotFoundException("No Loan found with the id in our system!!");
		}
		Loandetails.setStatus(-1);
		Loandetails.setRemark(rejectDto.getRemark());
		
		Users user = this.usersRepository.findById(managerId).orElse(null);
		//String role = user.getRole();
		if (user == null)
			throw new ManagerNotFoundException("No Manager found with the id in our system!!");
		Loan Loandetailsupdated = this.loanRepository.save(Loandetails);
		
		return rejectDto;
	}

	@Override
	public SanctionOutputDto sanctionLoan(Long managerId, Long loanAppId, SanctionDto sanctionDto) {
		// TODO Auto-generated method stub
		
		Users user = this.usersRepository.findById(managerId).orElse(null);
		String role = user.getRole();
		if (user == null || !role.equals("Manager"))
			throw new ManagerNotFoundException("No Manager found with the id in our system!!");
		
		Loan Loandetails = this.loanRepository.findById(loanAppId).orElse(null);
		if (Loandetails == null) {
			throw new LoanNotFoundException("No Loan found with the id in our system!!");
		}
		
		int statusval = Loandetails.getStatus();
		
		if (statusval==0) {
			throw new AlreadyFinalizedException("Loan is yet to be processed,  please contact the clerk ");
		}
		
		if (statusval==2) {
			throw new AlreadyFinalizedException("Loan is Already sanctioned");
		}
		
		if (statusval==-1) {
			throw new AlreadyFinalizedException("Loan is Already Rejected");
		}
			Loandetails.setStatus(2);
			Loandetails.setRemark("");
			Loan Loandetailsupdated = this.loanRepository.save(Loandetails);
			
			
			SanctionInfo sanctionInfo = this.convertSanctionInputDtoToEntity(managerId,loanAppId,sanctionDto);
			// save into DB, returns newly added record
			
			SanctionInfo newSancInfo = this.sanctionInfoRepository.save(sanctionInfo);
			// convert entity into dto
			SanctionOutputDto sancOutputDto =  this.convertSanctionEntityToOutputDto(newSancInfo);
			return sancOutputDto;
		
	}
}
		
