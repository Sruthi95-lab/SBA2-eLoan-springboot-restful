package com.iiht.training.eloan.dto;

import javax.validation.constraints.NotEmpty;

public class RejectDto {
	@NotEmpty(message="Remark is required while rejecting the loan")
	private String remark;

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
}
