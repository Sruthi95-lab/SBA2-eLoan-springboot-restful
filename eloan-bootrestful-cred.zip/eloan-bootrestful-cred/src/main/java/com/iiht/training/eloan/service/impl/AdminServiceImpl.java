package com.iiht.training.eloan.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.AdminService;



@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private UsersRepository usersRepository;
	
	// utility method
	private UserDto convertClerkEntityToOutputDto(Users users) 
	{
		UserDto userOutputDTO = new UserDto();
		userOutputDTO.setId(users.getId());
		userOutputDTO.setFirstName(users.getFirstName());
		userOutputDTO.setLastName(users.getLastName());
		userOutputDTO.setEmail(users.getEmail());
		userOutputDTO.setMobile(users.getMobile());
		
		return userOutputDTO;
	}
	
	private Users convertClerkInputDtoToEntity(UserDto userInputDTO) 
	{
		Users users = new Users();
		users.setId(userInputDTO.getId());
		users.setFirstName(userInputDTO.getFirstName());
		users.setLastName(userInputDTO.getLastName());
		users.setEmail(userInputDTO.getEmail());
		users.setMobile(userInputDTO.getMobile());
		users.setRole("Clerk");
		return users;
	}
		
	@Override
	public UserDto registerClerk(UserDto userInputDto) {
		// TODO Auto-generated method stub
		// convert dto into entity
				Users users = this.convertClerkInputDtoToEntity(userInputDto);
				// save into DB, returns newly added record
				Users newUser = this.usersRepository.save(users);
				// convert entity into dto
				UserDto userOutputDto =  this.convertClerkEntityToOutputDto(newUser);
				return userOutputDto;
	}
	
	@Autowired
	private UsersRepository managersRepository;
	
	// utility method
	private UserDto convertManagerEntityToOutputDto(Users users) 
	{
		UserDto userOutputDTO = new UserDto();
		userOutputDTO.setId(users.getId());
		userOutputDTO.setFirstName(users.getFirstName());
		userOutputDTO.setLastName(users.getLastName());
		userOutputDTO.setEmail(users.getEmail());
		userOutputDTO.setMobile(users.getMobile());
		
		return userOutputDTO;
	}
	
	private Users convertManagerInputDtoToEntity(UserDto userInputDTO) 
	{
		Users users = new Users();
		users.setId(userInputDTO.getId());
		users.setFirstName(userInputDTO.getFirstName());
		users.setLastName(userInputDTO.getLastName());
		users.setEmail(userInputDTO.getEmail());
		users.setMobile(userInputDTO.getMobile());
		users.setRole("Manager");
		return users;
	}
		

	@Override
	public UserDto registerManager(UserDto userInputDto) {
		// TODO Auto-generated method stub
		Users users = this.convertManagerInputDtoToEntity(userInputDto);
		// save into DB, returns newly added record
		Users newUser = this.managersRepository.save(users);
		// convert entity into dto
		UserDto userOutputDto =  this.convertManagerEntityToOutputDto(newUser);
		return userOutputDto;
	}

	@Autowired
	private UsersRepository allClerksRepository;
	
	// utility method
	private UserDto convertallClerkEntityToOutputDto(Users users) 
	{
		UserDto userOutputDTO = new UserDto();
		userOutputDTO.setId(users.getId());
		userOutputDTO.setFirstName(users.getFirstName());
		userOutputDTO.setLastName(users.getLastName());
		userOutputDTO.setEmail(users.getEmail());
		userOutputDTO.setMobile(users.getMobile());
		
		return userOutputDTO;
	}
	
	
	
	@Override
	public List<UserDto> getAllClerks() {
		// TODO Auto-generated method stub
		List<Users> clerks = this.allClerksRepository.findByRole("Clerk");
		List<UserDto> userDtos = 
				clerks.stream()
						 .map(this :: convertallClerkEntityToOutputDto)
						 .collect(Collectors.toList());
		return userDtos;
	}
	
	@Autowired
	private UsersRepository allManagersRepository;
	
	// utility method
	private UserDto convertallManagersEntityToOutputDto(Users users) 
	{
		UserDto userOutputDTO = new UserDto();
		userOutputDTO.setId(users.getId());
		userOutputDTO.setFirstName(users.getFirstName());
		userOutputDTO.setLastName(users.getLastName());
		userOutputDTO.setEmail(users.getEmail());
		userOutputDTO.setMobile(users.getMobile());
		
		return userOutputDTO;
	}
	
	@Override
	public List<UserDto> getAllManagers() {
		// TODO Auto-generated method stub
		List<Users> managers = this.allManagersRepository.findByRole("Manager");
		List<UserDto> userDtos = 
				managers.stream()
						 .map(this :: convertallManagersEntityToOutputDto)
						 .collect(Collectors.toList());
		return userDtos;
	}

}
