package com.iiht.training.eloan.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.LoanDto;
import com.iiht.training.eloan.dto.LoanOutputDto;
import com.iiht.training.eloan.dto.ProcessingDto;
import com.iiht.training.eloan.dto.SanctionOutputDto;
import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Loan;
import com.iiht.training.eloan.entity.ProcessingInfo;
import com.iiht.training.eloan.entity.SanctionInfo;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.exception.AlreadyProcessedException;
import com.iiht.training.eloan.exception.ClerkNotFoundException;
import com.iiht.training.eloan.exception.LoanNotFoundException;
import com.iiht.training.eloan.repository.LoanRepository;
import com.iiht.training.eloan.repository.ProcessingInfoRepository;
import com.iiht.training.eloan.repository.SanctionInfoRepository;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.ClerkService;

@Service
public class ClerkServiceImpl implements ClerkService {

	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private LoanRepository loanRepository;
	
	@Autowired
	private ProcessingInfoRepository pProcessingInfoRepository;
	
	@Autowired
	private SanctionInfoRepository sanctionInfoRepository;
	
	private UserDto convertCustomerEntityToOutputDto(Users users) 
	{
		UserDto userOutputDTO = new UserDto();
		userOutputDTO.setId(users.getId());
		userOutputDTO.setFirstName(users.getFirstName());
		userOutputDTO.setLastName(users.getLastName());
		userOutputDTO.setEmail(users.getEmail());
		userOutputDTO.setMobile(users.getMobile());
		
		return userOutputDTO;
	}
	
	
	
	private Users convertCustomerInputDtoToEntity(UserDto userInputDTO) 
	{
		Users users = new Users();
		users.setId(userInputDTO.getId());
		users.setFirstName(userInputDTO.getFirstName());
		users.setLastName(userInputDTO.getLastName());
		users.setEmail(userInputDTO.getEmail());
		users.setMobile(userInputDTO.getMobile());
		users.setRole("Customer");
		return users;
	}
	
	private ProcessingDto convertProcessEntityToOutputDto(ProcessingInfo processInfo) 
	{
		ProcessingDto processOutputDto = new ProcessingDto();
		processOutputDto.setAcresOfLand(processInfo.getAcresOfLand());
		processOutputDto.setLandValue(processInfo.getLandValue());
		processOutputDto.setAppraisedBy(processInfo.getAppraisedBy());
		processOutputDto.setValuationDate(processInfo.getValuationDate());
		processOutputDto.setAddressOfProperty(processInfo.getAddressOfProperty());
		processOutputDto.setSuggestedAmountOfLoan(processInfo.getSuggestedAmountOfLoan());
		
		return processOutputDto;
	}
	
	
	
	private ProcessingInfo convertProcessInputDtoToEntity(ProcessingDto processOutputDto) 
	{
		ProcessingInfo processInfo = new ProcessingInfo();
		processInfo.setAcresOfLand(processOutputDto.getAcresOfLand());
		processInfo.setLandValue(processOutputDto.getLandValue());
		processInfo.setAppraisedBy(processOutputDto.getAppraisedBy());
		processInfo.setValuationDate(processOutputDto.getValuationDate());
		processInfo.setAddressOfProperty(processOutputDto.getAddressOfProperty());
		processInfo.setSuggestedAmountOfLoan(processOutputDto.getSuggestedAmountOfLoan());
		return processInfo;
	}
	
	
	private LoanDto convertLoandetailsEntityToOutputDto(Loan loandetails) 
	{
		LoanDto loandetailsOutputDTO = new LoanDto();
		loandetailsOutputDTO.setLoanName(loandetails.getLoanName());
		loandetailsOutputDTO.setLoanAmount(loandetails.getLoanAmount());
		loandetailsOutputDTO.setLoanApplicationDate(loandetails.getLoanApplicationDate());
		loandetailsOutputDTO.setBusinessStructure(loandetails.getBusinessStructure());
		loandetailsOutputDTO.setBillingIndicator(loandetails.getBillingIndicator());
		loandetailsOutputDTO.setTaxIndicator(loandetails.getTaxIndicator());
		return loandetailsOutputDTO;
	}
	
	
	
	private LoanOutputDto convertloanEntityToOutputDto(Loan loan) 
	{
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		
		loanOutputDto.setLoanAppId(loan.getId());
		
		
		int statusval = loan.getStatus();
		switch(statusval) 
			{
			case 0:
				loanOutputDto.setStatus("APPLIED");
				break;
			case 1:
				loanOutputDto.setStatus("PROCESSED");
				break;
			case 2:
				loanOutputDto.setStatus("SANCTIONED");
				break;
			case -1:
				loanOutputDto.setStatus("REJECTED");
				break;
			}
		
		if(statusval==-1) {
			loanOutputDto.setRemark(loan.getRemark());
		}
		
		return loanOutputDto;
	}
	
	private SanctionOutputDto convertSanctionEntityToOutputDto(SanctionInfo newSancInfo) {
		
		SanctionOutputDto sanctionOutputDto = new SanctionOutputDto();
		sanctionOutputDto.setLoanAmountSanctioned(newSancInfo.getLoanAmountSanctioned());
		sanctionOutputDto.setLoanClosureDate(newSancInfo.getLoanClosureDate());
		sanctionOutputDto.setMonthlyPayment(newSancInfo.getMonthlyPayment());
		sanctionOutputDto.setPaymentStartDate(newSancInfo.getPaymentStartDate());
		sanctionOutputDto.setTermOfLoan(newSancInfo.getTermOfLoan());
		
		return sanctionOutputDto;
	}
	
	private LoanOutputDto convertlistloanEntityToOutputDto(Loan loan) 
	{
		
		
		
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		
		loanOutputDto.setCustomerId(loan.getCustomerId());
		Long customerId =loan.getCustomerId();
		Long Id =loan.getId();
		Long loanAppId =loan.getId();
		
		Users userdetails = this.usersRepository.findById(customerId).orElse(null);
		UserDto userdto = this.convertCustomerEntityToOutputDto(userdetails);
		
		Loan Loandetails = this.loanRepository.findById(Id).orElse(null);
		LoanDto loandto = this.convertLoandetailsEntityToOutputDto(Loandetails);
		
		int statusval = loan.getStatus();
		switch(statusval) 
			{
			case 0:
				loanOutputDto.setStatus("APPLIED");
				break;
			case 1:
				loanOutputDto.setStatus("PROCESSED");
				break;
			case 2:
				loanOutputDto.setStatus("SANCTIONED");
				break;
			case -1:
				loanOutputDto.setStatus("REJECTED");
				break;
			}
		
		if(statusval==-1) {
			loanOutputDto.setRemark(loan.getRemark());
		}
		
		if(statusval==1) {
			ProcessingInfo processinfo = this.pProcessingInfoRepository.findById(loanAppId).orElse(null);
			ProcessingDto processOutputDto = this.convertProcessEntityToOutputDto(processinfo);
			loanOutputDto.setProcessingDto(processOutputDto);
		}
		
		if(statusval==2){
			SanctionInfo sanctionInfo = this.sanctionInfoRepository.findById(loanAppId).orElse(null);
			SanctionOutputDto sanctionDto = this.convertSanctionEntityToOutputDto(sanctionInfo);
			loanOutputDto.setSanctionOutputDto(sanctionDto);
		}
		
		loanOutputDto.setLoanAppId(Id);
		loanOutputDto.setLoanDto(loandto);
		loanOutputDto.setUserDto(userdto);
		
		return loanOutputDto;
	}
	
	
	
	 @Override
	public List<LoanOutputDto> allAppliedLoans() {
		
		 List<Loan> Loans = this.loanRepository.findByStatus(0);
		 List<LoanOutputDto> loanDtos = Loans.stream()
							 .map(this ::convertlistloanEntityToOutputDto )
							 .collect(Collectors.toList());
			
			return loanDtos;
	 }

	@Override
	public ProcessingDto processLoan(Long clerkId, Long loanAppId, ProcessingDto processingDto) {
		// TODO Auto-generated method stub
		
		
		//Long status = 1L;
		
		Loan Loandetails = this.loanRepository.findById(loanAppId).orElse(null);
		if (Loandetails == null) {
			throw new LoanNotFoundException("Loan is not found in our system!!");
		}
		
		Users userdetails = this.usersRepository.findById(clerkId).orElse(null);
		//String role = userdetails.getRole();
		if (userdetails == null) {
			throw new ClerkNotFoundException("No details found for the provided Clerk ID in our system!!");
		}
		
		Loandetails.setStatus(1);
		Loan Loandetailsupdated = this.loanRepository.save(Loandetails);
		
		ProcessingInfo processInfo = this.convertProcessInputDtoToEntity(processingDto);
		// save into DB, returns newly added record
		processInfo.setLoanAppId(loanAppId);
		processInfo.setLoanClerkId(clerkId);
		ProcessingInfo newProcess = this.pProcessingInfoRepository.save(processInfo);
		// convert entity into dto
		ProcessingDto processOutputDto =  this.convertProcessEntityToOutputDto(newProcess);
		return processOutputDto;
	
		
		}

	


}

