package com.iiht.training.eloan.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.iiht.training.eloan.entity.Loan;
import com.iiht.training.eloan.entity.Users;


@Repository
public interface LoanRepository extends JpaRepository<Loan, Long>{

	List<Loan> findBycustomerId(Long customerId);
	List<Loan> findByStatus(int status);
	
	//@Query("update Loan set status ='1' where id=:id")
	//Loan findBySomeComplexQuery(@Param("status") Long status,@Param("id") Long loanAppId);
	
}
